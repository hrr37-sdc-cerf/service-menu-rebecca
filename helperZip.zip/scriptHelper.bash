#!/bin/bash
# //NODE INSTALL NVM
curl -o- https://raw.githubusercontent.com/nvm-sh/nvm/v0.34.0/install.sh | bash
source ~/.bashrc
# //INSTALL NODE
nvm install stable

sudo yum install -y
#POSTGRESS
cd ~
sudo yum update -y
sudo yum install npm
sudo yum install https://download.postgresql.org/pub/repos/yum/11/redhat/rhel-7-x86_64/pgdg-redhat11-11-2.noarch.rpm -y
sudo yum install postgresql11 -y
sudo yum install postgresql11-server -y
mkdir pg-db
/usr/pgsql-11/bin/initdb -D pg-db/
sudo chmod a+w /var/run/postgresql/
PGDATA=~/pg-db
/usr/pgsql-11/bin/pg_ctl -D pg-db/ start
/usr/pgsql-11/bin/createdb test

#GET GIT FILES
sudo yum install git -y
sleep 3
git clone https://github.com/hrr37-sdc-cerf/service-menu-rebecca.git
sleep 3
echo files rcvd from git

#RUN APPLICATION
cd ~
cd service-menu-rebecca
npm install
npm run csv-load;
npm start

